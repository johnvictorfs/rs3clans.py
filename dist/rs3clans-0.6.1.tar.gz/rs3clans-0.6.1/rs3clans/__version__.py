__author__ = 'John Victor'
__version__ = '0.6.1'
